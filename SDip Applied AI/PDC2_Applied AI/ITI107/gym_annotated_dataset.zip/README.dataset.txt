# mygymproject > 2025-01-01 5:39pm
https://universe.roboflow.com/shaiti107deep-learning-network/mygymproject

Provided by a Roboflow user
License: CC BY 4.0

